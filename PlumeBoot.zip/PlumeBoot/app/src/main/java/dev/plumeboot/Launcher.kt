package dev.plumeboot

import android.content.Context
import android.content.Intent

object Launcher {
    const val TARGET = "dev.plume"

    fun launch(context: Context): Boolean {
        val pm = context.packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(TARGET)
            ?: pm.getLaunchIntentForPackage(TARGET)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        context.startActivity(intent)
        return true
    }
}
