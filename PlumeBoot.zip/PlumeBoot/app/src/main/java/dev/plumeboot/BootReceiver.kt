package dev.plumeboot

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        // Beri jeda singkat agar sistem TV selesai booting
        Handler(Looper.getMainLooper()).postDelayed({
            try { Launcher.launch(context.applicationContext) } finally { pending.finish() }
        }, 5000)
    }
}
