package dev.plumeboot

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Android 10+ butuh izin "Tampil di atas aplikasi lain" agar boleh membuka app dari background
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin 'Display over other apps' untuk Plume Boot", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        } else if (!Launcher.launch(this)) {
            Toast.makeText(this, "Aplikasi ${Launcher.TARGET} belum terpasang", Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
